from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI(title="My Personal AI Assistant")

class Command(BaseModel):
    text: str

@app.get("/health")
def health():
    return {"ok": True}

@app.post("/command")
def command(payload: Command):
    # Replace this with your AI provider + tool router.
    text = payload.text.strip()

    if not text:
        return {"ok": False, "message": "Empty command"}

    return {
        "ok": True,
        "message": f"Received command: {text}",
        "next": "Connect AI tool-calling here."
    }

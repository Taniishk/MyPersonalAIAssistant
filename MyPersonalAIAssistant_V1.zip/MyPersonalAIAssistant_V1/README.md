# My Personal AI Assistant V1

This is a ready-to-open Android Studio starter project for a personal voice assistant.

Included:
- Android Kotlin app
- Foreground voice service
- "Hey Assistant" wake phrase detection using Android SpeechRecognizer
- Voice command capture after wake phrase
- Text-to-speech response
- Optional HTTP backend connection
- FastAPI backend starter
- Safe confirmation flow for actions
- Clear extension points for Google Sheets, Gmail, messaging and coding tools

IMPORTANT
---------
This V1 uses Android SpeechRecognizer as a prototype wake detector. It is NOT a dedicated low-power hotword engine.
For a production-grade always-listening wake word, replace WakeWordService with a dedicated wake-word SDK/engine such as Porcupine or an on-device keyword spotter.

Android setup
-------------
1. Open the `android` folder in Android Studio.
2. Let Android Studio install/sync the Android Gradle Plugin and dependencies.
3. Build and install on an Android phone.
4. Grant microphone and notification permissions.
5. Open the app and enable Assistant.
6. Say: "Hey Assistant"
7. Then speak a command.

Backend setup
-------------
The backend is optional for V1.

cd backend
python -m venv .venv
# Windows: .venv\Scripts\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn main:app --host 0.0.0.0 --port 8000

Set BACKEND_URL in the Android app to your server URL.

Security
--------
Do not put API keys inside the Android app.
Keep AI provider keys and Google OAuth secrets on the backend.
For send-email/send-message/payment/delete operations, require explicit confirmation.

Planned tools
-------------
- Google Sheets read/write
- Gmail draft/send
- Messaging
- File operations
- Web search
- Code/project generation
- Scheduled tasks

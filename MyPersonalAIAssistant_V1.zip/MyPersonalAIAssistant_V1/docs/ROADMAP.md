# V1 -> V2 roadmap

V1
- Android foreground service
- Wake phrase prototype
- Speech recognition
- Text-to-speech
- FastAPI command endpoint

V2
- AI tool calling
- Google OAuth
- Google Sheets read/write
- Gmail draft/send
- Explicit confirmation UI

V3
- Messaging tool
- File tools
- Web search/browser tools

V4
- Coding agent
- Isolated project workspace
- Build/test pipeline

V5
- Dedicated low-power wake-word engine
- Better background reliability
- Scheduling/automation
- Memory
